"""Static-only Daycup launcher: loopback, no accounts, uploads or external packages."""
from __future__ import annotations
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import mimetypes
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit
import webbrowser

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / 'web'
# No repository files, databases, directory listings or arbitrary nested paths.
ASSETS = {'index.html', 'app.js', 'i18n.js', 'rules.js', 'catalog-extension.js', 'brew-knowledge.js', 'equipment.js', 'bean-options.js',
          'curation.js', 'equipment-directory.json', 'bean-options.json',
          'style.css', 'manifest.json', 'sw.js', 'icon.svg', 'icon-180.png', 'icon-192.png',
          'icon-512.png', 'icon-maskable-512.png', 'privacy.html'}
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "connect-src 'self'; worker-src 'self'; manifest-src 'self'; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'self'")


def make_handler(base_path: str):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'DaycupLocal/1.1'
        def end_headers(self):
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', CSP)
            self.send_header('Cache-Control', 'no-cache')
            super().end_headers()

        def do_HEAD(self):
            self.serve(send_body=False)

        def do_GET(self):
            self.serve(send_body=True)

        def serve(self, send_body: bool):
            port = self.server.server_port
            if self.headers.get('Host') not in {f'127.0.0.1:{port}', f'localhost:{port}'}:
                self.send_error(403, 'Local host only')
                return
            raw_path = urlsplit(self.path).path
            path = unquote(raw_path)
            if base_path != '/' and path == base_path.rstrip('/'):
                self.send_response(308)
                self.send_header('Location', base_path)
                self.end_headers()
                return
            if not path.startswith(base_path):
                self.send_error(404)
                return
            asset = path[len(base_path):] or 'index.html'
            if asset not in ASSETS or '/' in asset or '\\' in asset:
                self.send_error(404)
                return
            file = WEB / asset
            if not file.is_file() or file.is_symlink():
                self.send_error(404)
                return
            body = file.read_bytes()
            mime = 'text/javascript' if file.suffix == '.js' else mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
            self.send_response(200)
            self.send_header('Content-Type', mime + ('; charset=utf-8' if file.suffix in {'.js', '.json', '.css', '.html', '.svg'} else ''))
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            if send_body:
                self.wfile.write(body)
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--port', type=int, default=8768)
    parser.add_argument('--base-path', default='/')
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error('Use a port from 1024 to 65535.')
    if not re.fullmatch(r'/(?:[A-Za-z0-9_-]+/)*', args.base_path):
        parser.error('Base path must start and end with /, such as /drops/daycup/app/.')
    missing = sorted(name for name in ASSETS if not (WEB / name).is_file())
    if missing:
        print('Daycup files are missing: ' + ', '.join(missing), file=sys.stderr)
        return 1
    if args.check:
        print('Daycup static files ready. No account server, API key or third-party package required.')
        return 0
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), make_handler(args.base_path))
    except OSError as error:
        print(f'Cannot open local port {args.port}: {error}. Close the earlier Daycup server and retry. '
              'The port is not changed automatically because a new address has separate browser records.', file=sys.stderr)
        return 1
    url = f'http://127.0.0.1:{args.port}{args.base_path}'
    print(f'Daycup: {url}\nKeep this terminal open. Ctrl+C stops the static server. No account API is running.', flush=True)
    if not args.headless:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
