@echo off
cd /d "%~dp0"
python scripts\launch.py
pause
