"""Source-motion reuse for budgeted LatentSync production, not new performances."""
import math
from pathlib import Path
from .render import RenderBlocked, run_job, _download, _ffmpeg, _assemble
from .ingest import probe
from .util import object_hash, read_json, write_json, sha256_file
from .mediacheck import check_tail_padding

ENDPOINT = 'fal-ai/latentsync'
TAIL_SECONDS = 0.8
MINIMUM_BILLED_SECONDS = 40
DISCLOSURE = 'AI-GENERATED CONTINUATION - SOURCE MOTION REUSED'


def reserved_cost(seconds, price):
    if not math.isfinite(seconds) or seconds <= 0 or not math.isfinite(price) or price <= 0:
        raise ValueError('positive_duration_and_price_required')
    # Account quote supplies the current per-second price. The model currently
    # bills at least 40 seconds, including on very short turns.
    return max(MINIMUM_BILLED_SECONDS, math.ceil(seconds + TAIL_SECONDS) + 1) * price


def cached_upload(provider, path, directory):
    digest = sha256_file(path)
    record = directory / ('upload-' + digest + '.json')
    if record.exists():
        value = read_json(record)
        if value.get('checksum') != digest or not isinstance(value.get('url'), str):
            raise RenderBlocked('invalid_cached_upload')
        return value['url']
    # The existing provider bounds storage timeouts and disables unbounded fallback.
    url = provider.upload(path)
    write_json(record, {'checksum': digest, 'url': url})
    record.chmod(0o600)
    return url


def render_source_video(provider, ledger, speakers, frozen, folder, identity, digest, price, poll_seconds=0):
    videos, checks = [], []
    for index, chunk in enumerate(frozen['chunks']):
        if chunk['duration_seconds'] > 90:
            raise RenderBlocked('lipsync_turn_over_90_seconds_resegment_reviewed_script_in_new_run')
        speaker = speakers[chunk['speaker_id']]
        padded = folder / ('lipsync_driver_%03d.wav' % index)
        if not padded.exists():
            _ffmpeg(['-i', chunk['path'], '-af', 'apad=pad_dur=0.8', '-ac', '1', '-ar', '24000', '-c:a', 'pcm_s16le', padded])
        # Drivers are derived from the already hash-checked frozen track. Preserve
        # their hashes too, so manual edits cannot silently change resumed inputs.
        driver_hash = sha256_file(padded)
        spec = {'production_hash': identity, 'script_hash': digest, 'endpoint': ENDPOINT,
                'turn_id': chunk['turn_id'], 'source_video_hash': speaker['source_video_hash'],
                'audio_hash': chunk['checksum'], 'driver_hash': driver_hash,
                'frozen_audio_hash': frozen['audio_hash'], 'tail_seconds': TAIL_SECONDS,
                'source_video_permission_proof': speaker['source_video_permission_proof'],
                'motion_policy': 'reuse_single_speaker_source_motion_loop', 'seed': 42,
                'minimum_billed_seconds': MINIMUM_BILLED_SECONDS}
        previous = next((j for j in ledger.jobs() if j['operation'] == 'lipsync_video' and
                         j['metadata'].get('production_hash') == identity and j['metadata'].get('turn_id') == chunk['turn_id']), None)
        if previous and previous['metadata'] != spec:
            raise RenderBlocked('lipsync_driver_or_metadata_changed_new_run_required')
        result = run_job(provider, ledger, 'lipsync_video', object_hash(spec), reserved_cost(chunk['duration_seconds'], price), ENDPOINT,
                         lambda: {'video_url': cached_upload(provider, speaker['source_video'], folder),
                                  'audio_url': cached_upload(provider, padded, folder), 'loop_mode': 'loop', 'seed': 42},
                         metadata=spec, poll_seconds=poll_seconds)
        asset = _download(provider, result, 'video', folder / ('lipsync_%03d.mp4' % index))
        check = check_tail_padding(asset['path'], chunk['path'], folder / ('lipsync_alignment_%03d' % index),
                                   target_seconds=chunk['duration_seconds'], allow_short_tail=True, require_raw_correlation=True)
        check.update(turn_id=chunk['turn_id'], video_checksum=asset['checksum'], audio_checksum=chunk['checksum'])
        write_json(folder / ('lipsync_alignment_%03d.json' % index), check)
        if check['status'] != 'verified_tail_padding':
            raise RenderBlocked('lipsync_complete_audio_alignment_failed:' + ','.join(check['issues']))
        videos.append(asset); checks.append(check)
    assembled = _assemble(videos, frozen, folder)
    final = folder / 'final.labeled.mp4'
    # A fixed, non-user-provided filter string; every exported frame carries the
    # disclosure even after it leaves the website. Native outputs stay preserved.
    _ffmpeg(['-i', assembled['path'], '-vf', "drawtext=text='" + DISCLOSURE + "':fontsize=18:fontcolor=white:box=1:boxcolor=black@0.72:boxborderw=5:x=14:y=14",
             '-c:v', 'libx264', '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'copy', '-movflags', '+faststart', final])
    result = dict(assembled, path=str(final), checksum=sha256_file(final), media_info=probe(final),
                  alignment_evidence=checks, disclosure=DISCLOSURE, source_motion_reused=True,
                  quality_status='audio_coverage_checked_visual_and_perceptual_review_required')
    return videos, result
