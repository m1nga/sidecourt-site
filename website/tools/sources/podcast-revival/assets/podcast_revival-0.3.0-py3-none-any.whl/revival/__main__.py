import argparse,json,sys
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(prog='revival',description='A private, evidence-bound podcast continuation workbench')
    parser.add_argument('command',choices=['produce','brief','validate','plan','ingest','draft','review','preflight','run','render','resume','report','reconcile','serve'])
    parser.add_argument('--config',default=None)
    parser.add_argument('--dry-run',action='store_true')
    parser.add_argument('--execute',action='store_true',help='Execute authorized production; produce otherwise defaults to offline dry-run')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--port',type=int,default=4317)
    parser.add_argument('--input',help='Revival website brief JSON (brief command)')
    parser.add_argument('--out',help='New project directory to create (brief command)')
    parser.add_argument('--text-file',help='UTF-8 source text file (brief command)')
    parser.add_argument('--duration',type=int,help='Target duration in seconds, 1–86400 (brief command)')
    parser.add_argument('--tone',choices=['curious','balanced','skeptical','constructive','warm'],help='Editorial attitude (brief command)')
    parser.add_argument('--viewpoint',help='Question or point of view to explore (brief command)')
    parser.add_argument('--material',action='append',default=[],help='Actual local material file; repeat for multiple files (brief command)')
    args=parser.parse_args()
    if args.command=='produce':
        if not args.input or not args.out:parser.error('The produce command requires --input PRODUCTION_JSON --out RUN_DIRECTORY')
        if args.resume and (args.execute or args.dry_run):parser.error('Use --resume alone; it is a GET-only recovery action')
        try:
            from .produce import produce
            if args.execute or args.resume:
                from .app import load_credentials
                load_credentials()
            result=produce(args.input,args.out,dry_run=args.dry_run or not(args.execute or args.resume),resume=args.resume)
            print(json.dumps(result,ensure_ascii=False,indent=2))
            if result.get('status')=='blocked':sys.exit(2)
            return
        except (OSError,ValueError,TypeError) as e:
            print(json.dumps({'status':'blocked','error':str(e),'new_submissions':0},ensure_ascii=False));sys.exit(2)
    if args.command=='brief':
        if not args.out:parser.error('The brief command requires --out NEW_DIRECTORY')
        try:
            from .brief import create_brief
            result=create_brief(out=args.out,input_path=args.input,text_file=args.text_file,
                                duration=args.duration,tone=args.tone,viewpoint=args.viewpoint,materials=args.material)
            print(json.dumps(result,ensure_ascii=False,indent=2));return
        except (OSError,ValueError,TypeError) as e:
            print(json.dumps({'status':'blocked','error':str(e),'paid_calls':0},ensure_ascii=False));sys.exit(2)
    from .app import Project,load_credentials
    config=Path(args.config).expanduser() if args.config else Path.cwd()/'projects/pilot/project.json'
    if not config.is_file():parser.error('Pass --config PATH to an existing project.json; the local pilot is projects/pilot/project.json')
    load_credentials();p=Project(config)
    if args.command=='serve':
        from .server import serve
        serve(p,args.port);return
    command={'validate':'preflight','run':'resume' if args.resume else 'render'}.get(args.command,args.command)
    if args.dry_run and command in ('render','resume'):command='preflight'
    try:
        result=p.action(command);print(json.dumps(result,ensure_ascii=False,indent=2))
        if result.get('status') in ('blocked','failed') or result.get('decision')=='blocked':sys.exit(2)
    except Exception as e:
        print(json.dumps({'status':'blocked','error':str(e)},ensure_ascii=False));sys.exit(2)
if __name__=='__main__':main()
