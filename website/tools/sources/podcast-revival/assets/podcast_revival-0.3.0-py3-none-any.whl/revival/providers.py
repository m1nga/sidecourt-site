"""Small fal queue client. POST is deliberately never retried.

A timeout submitting a request is an uncertain paid submission, not a failed job.
Transport injection accepts (method, url, headers, data, timeout) and returns
JSON dictionaries (or bytes for downloads). No network occurs at construction.
"""
import base64
import json
import inspect
import mimetypes
import os
import re
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, build_opener, HTTPRedirectHandler


class ProviderError(RuntimeError):
    pass


class SubmissionUnknown(ProviderError):
    pass


class SubmissionRejected(ProviderError):
    """Explicit HTTP rejection of this new POST, without private response text."""
    def __init__(self, status_code):
        self.status_code = int(status_code)
        self.code = self.status_code
        categories = {400: 'invalid_request', 401: 'authentication_rejected',
                      402: 'payment_required', 403: 'permission_denied',
                      404: 'endpoint_not_found', 405: 'method_not_allowed',
                      413: 'payload_too_large', 415: 'unsupported_media_type',
                      422: 'input_validation_rejected', 429: 'rate_limited'}
        self.safe_message = 'fal submission rejected: HTTP ' + str(self.status_code) + ' (' + categories.get(self.status_code, 'request_rejected') + ')'
        super().__init__(self.safe_message)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ProviderError("Redirect refused; credentials must not cross hosts")


class FalProvider:
    def __init__(self, key=None, transport=None, timeout=30, get_retries=2):
        self.key = key if key is not None else os.environ.get("FAL_KEY")
        self.transport = transport
        self.timeout = timeout
        self.get_retries = get_retries

    @staticmethod
    def _check_auth_url(url):
        parsed = urlparse(url)
        if (parsed.scheme != "https" or parsed.hostname not in {"queue.fal.run", "api.fal.ai"}
                or parsed.username or parsed.password or parsed.port not in (None, 443)):
            raise ProviderError("Refusing to send fal credentials to untrusted URL")

    def _request(self, method, url, payload=None, auth=True, raw=False):
        headers = {}
        if auth:
            self._check_auth_url(url)
            if not self.key:
                raise ProviderError("missing_credential: FAL_KEY")
            headers["Authorization"] = "Key " + self.key
        data = None if payload is None else json.dumps(payload).encode()
        if data is not None:
            headers["Content-Type"] = "application/json"
        attempts = self.get_retries + 1 if method == "GET" else 1
        for attempt in range(attempts):
            try:
                if self.transport:
                    result = self.transport(method, url, headers, data, self.timeout)
                else:
                    request = Request(url, data=data, headers=headers, method=method)
                    with build_opener(_NoRedirect()).open(request, timeout=self.timeout) as response:
                        result = response.read()
                if raw:
                    return result if isinstance(result, bytes) else json.dumps(result).encode()
                return json.loads(result) if isinstance(result, (bytes, str)) else result
            except (OSError, TimeoutError, URLError) as exc:
                if method == "POST":
                    # 408/499 can describe an interrupted transport after work
                    # reached the server. Preserve uncertainty for those and
                    # every 5xx/timeout; never reinterpret historical unknowns.
                    if isinstance(exc, HTTPError) and 400 <= exc.code < 500 and exc.code not in (408, 499):
                        raise SubmissionRejected(exc.code) from None
                    raise SubmissionUnknown("Submission outcome unknown; do not resubmit") from exc
                # Authentication and client errors are not transient.
                if isinstance(exc, HTTPError) and exc.code < 500 and exc.code != 429:
                    raise ProviderError("fal GET failed with HTTP " + str(exc.code)) from exc
                if attempt + 1 == attempts:
                    raise ProviderError("fal GET unavailable; retain original request") from exc
                time.sleep(min(2 ** attempt, 4))
        raise ProviderError("request unavailable")

    def submit(self, endpoint, payload):
        if not re.fullmatch(r"[A-Za-z0-9_./-]+", endpoint) or ".." in endpoint:
            raise ProviderError("Invalid endpoint")
        result = self._request("POST", "https://queue.fal.run/" + endpoint.strip("/"), payload)
        # A malformed response may still represent an accepted paid job.
        if not isinstance(result, dict) or not result.get("request_id"):
            raise SubmissionUnknown("Submission returned no request_id; reconcile before retry")
        for name in ("status_url", "response_url", "cancel_url"):
            if result.get(name):
                self._check_auth_url(result[name])
        return result

    def status(self, url):
        return self._request("GET", url)

    def result(self, url):
        return self._request("GET", url)

    def pricing(self, endpoint):
        return self._request("GET", "https://api.fal.ai/v1/models/pricing?" + urlencode({"endpoint_id": endpoint}))

    def billing_events(self, request_id):
        return self._request("GET", "https://api.fal.ai/v1/models/billing-events?" + urlencode({"request_id": request_id}))

    def upload(self, path):
        """Use inline data URIs first for small model assets (at most 5 MiB).

        Large assets use the SDK's supported default_timeout. This bounds each
        SDK storage request; no large upload is attempted by an SDK that lacks
        that supported timeout control. Preparing input never submits inference.
        """
        path = Path(path)
        if path.stat().st_size <= 5 * 1024 * 1024:
            media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            return "data:" + media_type + ";base64," + base64.b64encode(path.read_bytes()).decode()
        try:
            import fal_client
        except ImportError:
            raise ProviderError("Large asset requires fal-client storage upload; compress the necessary crop below 5 MiB for inline input")
        if not self.key:
            raise ProviderError("missing_credential: FAL_KEY for large asset storage upload")
        try:
            supports_timeout = "default_timeout" in inspect.signature(fal_client.SyncClient).parameters
        except (TypeError, ValueError):
            supports_timeout = False
        if not supports_timeout:
            raise ProviderError("Installed fal-client has no supported upload timeout control; compress crop below 5 MiB")
        # Installed SDK source confirms CDN client uses default_timeout. It is a
        # per-request timeout, not a promise of a wall-clock total upload limit.
        upload_timeout = max(1.0, min(float(self.timeout), 30.0))
        client = fal_client.SyncClient(key=self.key, default_timeout=upload_timeout)
        try:
            upload_parameters = inspect.signature(client.upload_file).parameters
        except (TypeError, ValueError):
            raise ProviderError("Cannot verify bounded storage upload options")
        if not {'repository', 'fallback_repository'}.issubset(upload_parameters):
            raise ProviderError("SDK cannot explicitly disable unbounded legacy storage fallback; compress below 5 MiB")
        # Installed SDK's legacy `fal` fallback passes timeout=None on its PUT,
        # so default_timeout alone does not bound it. Empty fallback is explicit
        # (None would re-enable the SDK default fallback to `fal`).
        return client.upload_file(str(path), repository="fal_v3", fallback_repository=[])

    def download(self, url, dest):
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.username or parsed.password:
            raise ProviderError("Only HTTPS media downloads are accepted")
        # Never attach FAL_KEY to CDN or user-provided download URLs.
        body = self._request("GET", url, auth=False, raw=True)
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        temp = dest.with_suffix(dest.suffix + ".partial")
        temp.write_bytes(body)
        temp.replace(dest)
        return str(dest)
