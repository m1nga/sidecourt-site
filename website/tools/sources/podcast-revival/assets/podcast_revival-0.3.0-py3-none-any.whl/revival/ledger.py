"""Durable reservations: a completed but unbilled call still consumes its bound."""
import json
import math
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from .util import now

class BudgetError(RuntimeError): pass
class StateError(RuntimeError): pass

class Ledger:
    def __init__(self, path, limit_usd=100):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.limit = self._amount(limit_usd)
        with self._db() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS jobs (
              job_id TEXT PRIMARY KEY, fingerprint TEXT UNIQUE NOT NULL,
              operation TEXT NOT NULL, upper_bound INTEGER NOT NULL,
              state TEXT NOT NULL, metadata TEXT NOT NULL, request_id TEXT,
              urls TEXT NOT NULL DEFAULT '{}', result TEXT, actual INTEGER,
              receipt_ref TEXT, reason TEXT, created_at TEXT, updated_at TEXT);
              CREATE TABLE IF NOT EXISTS cash (receipt_ref TEXT PRIMARY KEY, amount INTEGER NOT NULL, created_at TEXT);''')
    @staticmethod
    def _amount(value):
        if isinstance(value, bool) or not isinstance(value, (int,float)) or not math.isfinite(value) or value < 0:
            raise ValueError('Amount must be a finite non-negative number')
        return int(math.ceil(value*1000000-1e-8))
    @contextmanager
    def _db(self):
        db = sqlite3.connect(str(self.path),timeout=30,isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        try:
            db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except Exception:
            db.rollback(); raise
        finally: db.close()
    @staticmethod
    def _row(row):
        if row is None: return None
        result=dict(row)
        for k in ['metadata','urls','result']:
            result[k]=json.loads(result[k]) if result[k] is not None else None
        result['upper_bound']=result['upper_bound']/1e6
        result['actual_cost']=None if result['actual'] is None else result['actual']/1e6
        result['actual_billed_amount']=result['actual_cost']
        result['reserved_amount']=result['upper_bound'] if result['actual'] is None and result['state']!='cancelled' else 0
        del result['actual']
        return result
    def reserve(self,operation,fingerprint,upper_bound,metadata=None,minimum_remaining=0):
        amount=self._amount(upper_bound); floor=self._amount(minimum_remaining)
        if not fingerprint or not operation: raise ValueError('Operation and fingerprint required')
        with self._db() as db:
            old=db.execute('SELECT * FROM jobs WHERE fingerprint=?',(fingerprint,)).fetchone()
            if old:
                if old['operation']!=operation or old['upper_bound']!=amount or json.loads(old['metadata'])!=(metadata or {}):raise StateError('Fingerprint already exists with a different operation, bound, or metadata')
                return self._row(old)
            used=db.execute("SELECT COALESCE(SUM(CASE WHEN actual IS NOT NULL THEN actual WHEN state!='cancelled' THEN upper_bound ELSE 0 END),0) FROM jobs").fetchone()[0]
            if used+amount+floor>self.limit: raise BudgetError('Insufficient budget after preserving remaining work and buffers')
            jid=uuid.uuid4().hex
            db.execute('INSERT INTO jobs(job_id,fingerprint,operation,upper_bound,state,metadata,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)',(jid,fingerprint,operation,amount,'reserved',json.dumps(metadata or {}),now(),now()))
            return self._row(db.execute('SELECT * FROM jobs WHERE job_id=?',(jid,)).fetchone())
    def start(self,job_id):
        with self._db() as db:
            cursor=db.execute("UPDATE jobs SET state='submitting',updated_at=? WHERE job_id=? AND state='reserved'",(now(),job_id))
            return cursor.rowcount==1
    def _update(self,job_id,query,args,allowed=None):
        with self._db() as db:
            row=db.execute('SELECT * FROM jobs WHERE job_id=?',(job_id,)).fetchone()
            if row is None: raise StateError('Unknown job')
            if allowed and row['state'] not in allowed: raise StateError('Invalid transition from '+row['state'])
            db.execute(query,(*args,now(),job_id))
    def submitted(self,job_id,request_id,urls):
        if not request_id: raise ValueError('Provider request ID required')
        self._update(job_id,"UPDATE jobs SET state='queued',request_id=?,urls=?,updated_at=? WHERE job_id=?",(request_id,json.dumps(urls)),{'submitting','unknown','queued'})
    def unknown(self,job_id,reason):
        self._update(job_id,"UPDATE jobs SET state='unknown',reason=?,updated_at=? WHERE job_id=?",(str(reason),),{'submitting','queued','unknown'})
    def rejected(self,job_id,reason):
        # Explicit HTTP rejection is distinct from uncertain acceptance. Keep
        # its financial bound until a billing receipt establishes actual cost.
        self._update(job_id,"UPDATE jobs SET state='rejected',reason=?,updated_at=? WHERE job_id=?",(str(reason),),{'submitting'})
    def complete(self,job_id,result):
        self._update(job_id,"UPDATE jobs SET state='completed',result=?,updated_at=? WHERE job_id=?",(json.dumps(result),),{'queued','submitting','unknown','completed'})
    def reconcile(self,job_id,actual_cost,receipt_ref):
        amount=self._amount(actual_cost)
        if not receipt_ref: raise ValueError('A verified receipt reference is required')
        with self._db() as db:
            row=db.execute('SELECT * FROM jobs WHERE job_id=?',(job_id,)).fetchone()
            if not row: raise StateError('Unknown job')
            if row['actual'] is not None:
                if row['actual']!=amount or row['receipt_ref']!=receipt_ref: raise StateError('Conflicting receipt; reconcile explicitly')
                return
            if row['state']=='reserved': raise StateError('Unsubmitted job cannot have a bill')
            db.execute('UPDATE jobs SET actual=?,receipt_ref=?,updated_at=? WHERE job_id=?',(amount,receipt_ref,now(),job_id))
    def cancel_unsubmitted(self,job_id):
        self._update(job_id,"UPDATE jobs SET state='cancelled',updated_at=? WHERE job_id=?",(),{'reserved'})
    def record_cash(self,amount,receipt_ref):
        value=self._amount(amount)
        if not receipt_ref: raise ValueError('Cash receipt required')
        with self._db() as db:
            prior=db.execute('SELECT amount FROM cash WHERE receipt_ref=?',(receipt_ref,)).fetchone()
            if prior:
                if prior[0]!=value: raise StateError('Conflicting cash receipt')
                return
            used=db.execute('SELECT COALESCE(SUM(amount),0) FROM cash').fetchone()[0]
            if used+value>self.limit: raise BudgetError('New cash outlay would exceed limit')
            db.execute('INSERT INTO cash VALUES(?,?,?)',(receipt_ref,value,now()))
    def get(self,job_id):
        with self._db() as db: return self._row(db.execute('SELECT * FROM jobs WHERE job_id=?',(job_id,)).fetchone())
    def jobs(self):
        with self._db() as db: return [self._row(r) for r in db.execute('SELECT * FROM jobs ORDER BY created_at')]
    def totals(self):
        jobs=self.jobs();settled=sum(j['actual_cost'] or 0 for j in jobs);pending=sum(j['reserved_amount'] for j in jobs)
        with self._db() as db: cash=db.execute('SELECT COALESCE(SUM(amount),0) FROM cash').fetchone()[0]/1e6
        return {'limit_usd':self.limit/1e6,'settled_usd':round(settled,6),'pending_usd':round(pending,6),'available_usd':round(self.limit/1e6-settled-pending,6),'new_cash_outlay_usd':cash,'unbilled_jobs':sum(j['actual_cost'] is None and j['state'] not in ('reserved','cancelled') for j in jobs),'budget_exceeded':settled+pending>self.limit/1e6,'actual_cost_usd':round(settled,6) if jobs and all(j['actual_cost'] is not None or j['state']=='cancelled' for j in jobs) else None}
