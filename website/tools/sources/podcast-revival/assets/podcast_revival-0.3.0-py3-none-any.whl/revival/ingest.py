"""Deterministic, local-only media intake. All ranges use source-absolute ms."""
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
from datetime import datetime, timezone


class MediaError(RuntimeError):
    pass


def _binary(name):
    configured = os.environ.get('REVIVAL_' + name.upper())
    if configured:
        candidate = shutil.which(configured)
        return candidate or (configured if Path(configured).is_file() and os.access(configured, os.X_OK) else None)
    found = shutil.which(name)
    if found:
        return found
    if name == 'ffmpeg':
        try:
            return importlib.import_module('imageio_ffmpeg').get_ffmpeg_exe()
        except (ImportError, RuntimeError, OSError):
            pass
    ffmpeg = _binary('ffmpeg') if name == 'ffprobe' else None
    if ffmpeg:
        sibling = Path(ffmpeg).with_name('ffprobe')
        if sibling.is_file() and os.access(str(sibling), os.X_OK):
            return str(sibling)
    return None


def _run(args, check=True):
    result = subprocess.run([str(a) for a in args], shell=False, capture_output=True, text=True, timeout=180)
    if check and result.returncode:
        raise MediaError(result.stderr[-3000:] or 'Media command failed')
    return result


def probe(path):
    """Read actual media metadata; raise MediaError when unavailable/undecodable."""
    path = Path(path).resolve()
    if not path.is_file():
        raise MediaError('Source file does not exist: ' + str(path))
    ffprobe = _binary('ffprobe')
    if ffprobe:
        raw = json.loads(_run([ffprobe, '-v', 'error', '-show_format', '-show_streams', '-of', 'json', path]).stdout)
        streams = raw.get('streams', [])
        video = next((s for s in streams if s.get('codec_type') == 'video'), {})
        duration = raw.get('format', {}).get('duration')
        if duration is None:
            duration = max((float(s.get('duration', 0)) for s in streams), default=0)
        result = {'duration_seconds': float(duration), 'width': video.get('width'), 'height': video.get('height'),
                  'has_audio': any(s.get('codec_type') == 'audio' for s in streams)}
    else:
        ffmpeg = _binary('ffmpeg')
        if not ffmpeg:
            raise MediaError('Missing ffprobe and ffmpeg; configure REVIVAL_FFMPEG/REVIVAL_FFPROBE')
        # Bundled imageio ffmpeg often has no ffprobe. Decode metadata is real, not fixture values.
        output = _run([ffmpeg, '-hide_banner', '-i', path], check=False).stderr
        duration = re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)', output)
        if not duration:
            raise MediaError('Cannot determine actual media duration: ' + output[-1500:])
        dimensions = re.search(r'Video:.*?\b(\d{2,6})x(\d{2,6})\b', output)
        h, m, s = duration.groups()
        result = {'duration_seconds': int(h) * 3600 + int(m) * 60 + float(s),
                  'width': int(dimensions[1]) if dimensions else None,
                  'height': int(dimensions[2]) if dimensions else None,
                  'has_audio': bool(re.search(r'Stream .*Audio:', output))}
    if not math.isfinite(result['duration_seconds']) or result['duration_seconds'] <= 0:
        raise MediaError('Media has no finite positive duration')
    result['audio_present'] = result['has_audio']
    return result


def midpoint_window(duration_seconds, half_window=300):
    """Return the middle window, capped to 600 seconds even for larger arguments."""
    duration = float(duration_seconds)
    half = min(float(half_window), 300.0)
    if not math.isfinite(duration) or duration <= 0 or not math.isfinite(half) or half <= 0:
        raise ValueError('duration_seconds and half_window must be finite and positive')
    center = duration * 500
    return [max(0, int(round(center - half * 1000))), min(int(round(duration * 1000)), int(round(center + half * 1000)))]


def _issue(code, message, severity='error'):
    return {'code': code, 'message': message, 'severity': severity}


def _range(value):
    return (isinstance(value, (list, tuple)) and len(value) == 2
            and all(isinstance(n, (int, float)) and not isinstance(n, bool) and math.isfinite(n) for n in value)
            and 0 <= value[0] < value[1])


def _inside(value, context):
    return _range(value) and context[0] <= value[0] < value[1] <= context[1]


def _path(value, base_dir):
    path = Path(value).expanduser()
    return (Path(base_dir) / path).resolve() if not path.is_absolute() else path.resolve()


def _validate(source, base_dir, metadata=None):
    issues = []
    if not isinstance(source, dict):
        return [_issue('invalid_source', 'Source must be an object')]
    for field in ('source_id', 'local_path', 'published_at'):
        if not isinstance(source.get(field), str) or not source[field].strip():
            issues.append(_issue('missing_' + field, field + ' is required'))
    if isinstance(source.get('published_at'), str) and source['published_at']:
        try:
            datetime.fromisoformat(source['published_at'].replace('Z', '+00:00'))
        except (ValueError, TypeError):
            issues.append(_issue('invalid_published_at', 'published_at must be an ISO date or timestamp'))
    if source.get('language') not in ('zh', 'en'):
        issues.append(_issue('invalid_language', 'language must be zh or en'))
    fixture = source.get('synthetic_fixture') is True
    for flag in ('attribution_verified', 'language_verified'):
        if not fixture and source.get(flag) is not True:
            issues.append(_issue('unverified_' + flag.removesuffix('_verified'), flag + ' must be explicitly true for live intake'))
    if metadata is None and isinstance(source.get('local_path'), str) and source['local_path']:
        try:
            metadata = probe(_path(source['local_path'], base_dir))
        except (MediaError, OSError, ValueError, subprocess.SubprocessError) as exc:
            issues.append(_issue('media_probe_failed', str(exc)))
    context = midpoint_window(metadata['duration_seconds']) if metadata else None
    if metadata and (not metadata['has_audio'] or not metadata['width'] or not metadata['height']):
        issues.append(_issue('missing_media_stream', 'Source needs actual video and audio streams'))
    selected = source.get('selected_range_ms')
    if not _range(selected):
        issues.append(_issue('invalid_selection', 'selected_range_ms must be a positive [start_ms, end_ms] pair'))
    elif context and not _inside(selected, context):
        issues.append(_issue('selection_outside_context', 'Selection must be within the middle maximum 600 second context'))
    elif selected[1] - selected[0] < 180000 or selected[1] - selected[0] > 300000:
        issues.append(_issue('selection_duration', 'Select a continuous 3–5 minute passage', 'warning'))
    speakers = source.get('speakers')
    if not isinstance(speakers, list):
        speakers = []
    ids = [s.get('speaker_id') for s in speakers if isinstance(s, dict)]
    if not 2 <= len(speakers) <= 4 or len(ids) != len(speakers) or any(not isinstance(i, str) or not i.strip() for i in ids) or len(set(str(i) for i in ids)) != len(ids):
        issues.append(_issue('speaker_mismatch', 'Source requires 2–4 actual, unique, nonempty speaker IDs'))
    occupied = []
    for index, speaker in enumerate(speakers):
        if not isinstance(speaker, dict):
            issues.append(_issue('invalid_speaker', 'Speaker must be an object'))
            continue
        sid = speaker.get('speaker_id', str(index))
        if not isinstance(speaker.get('display_name'), str) or not speaker['display_name'].strip():
            issues.append(_issue('missing_display_name', str(sid) + ': display_name required'))
        permission = speaker.get('permission') or {}
        if not isinstance(permission, dict) or not isinstance(permission.get('allowed_uses'), list) or not permission.get('allowed_uses') or not isinstance(permission.get('proof_ref'), str) or not permission.get('proof_ref'):
            issues.append(_issue('missing_permission', str(sid) + ': allowed_uses and proof_ref required'))
        portrait = speaker.get('portrait_timestamp_ms')
        if not isinstance(portrait, (int, float)) or isinstance(portrait, bool) or not math.isfinite(portrait) or portrait < 0 or (context and not context[0] <= portrait < context[1]):
            issues.append(_issue('portrait_outside_context', str(sid) + ': portrait timestamp must be inside source context'))
        crop = speaker.get('portrait_crop')
        if crop is not None:
            valid = isinstance(crop, (list, tuple)) and len(crop) == 4 and all(isinstance(n, int) and not isinstance(n, bool) for n in crop)
            valid = valid and crop[0] >= 0 and crop[1] >= 0 and crop[2] > 0 and crop[3] > 0
            valid = valid and (not metadata or (crop[0] + crop[2] <= (metadata['width'] or 0) and crop[1] + crop[3] <= (metadata['height'] or 0)))
            if not valid:
                issues.append(_issue('invalid_portrait_crop', str(sid) + ': crop must fit actual video dimensions'))
        for kind in ('enrollment', 'calibration'):
            ranges = speaker.get(kind + '_ranges_ms', [])
            if not isinstance(ranges, list) or not ranges:
                issues.append(_issue('missing_' + kind, str(sid) + ': ' + kind + ' ranges required'))
                continue
            total = 0
            for r in ranges:
                if not _range(r) or (context and not _inside(r, context)):
                    issues.append(_issue('range_outside_context', str(sid) + ': invalid ' + kind + ' range ' + repr(r)))
                    continue
                total += r[1] - r[0]
                occupied.append((r[0], r[1], sid, kind))
            if kind == 'enrollment':
                if not 10000 <= total <= 300000:
                    issues.append(_issue('reference_duration', str(sid) + ': reference must total 10–300 seconds'))
                elif not 30000 <= total <= 60000:
                    issues.append(_issue('reference_target', str(sid) + ': reference target is 30–60 seconds', 'warning'))
                if total * 32 + 44 > 20 * 1024 * 1024:
                    issues.append(_issue('reference_size', str(sid) + ': reference would exceed 20 MiB'))
            elif total < 5000:
                issues.append(_issue('calibration_coverage', str(sid) + ': calibration needs at least 5 seconds'))
    occupied.sort(key=lambda r: (r[0], r[1]))
    for i, first in enumerate(occupied):
        for second in occupied[i + 1:]:
            if second[0] >= first[1]:
                break
            issues.append(_issue('overlapping_ranges', '{} {} overlaps {} {}; source speech cannot be reused as independent calibration or assigned to two people'.format(first[2], first[3], second[2], second[3])))
    transcript = source.get('transcript_path', source.get('transcript'))
    if transcript is not None:
        if not isinstance(transcript, str) or not _path(transcript, base_dir).is_file():
            issues.append(_issue('missing_transcript', 'Optional transcript path must name an existing local file'))
    return issues


def validate_source(source, base_dir):
    return _validate(source, Path(base_dir))


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _extract(source, metadata, run_dir):
    ffmpeg = _binary('ffmpeg')
    if not ffmpeg:
        raise MediaError('Missing ffmpeg: local asset extraction is blocked')
    # Folder identity is derived from source content and config, never a supplied path component.
    identity = hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()[:16]
    folder = run_dir / 'assets' / identity
    folder.mkdir(parents=True, exist_ok=True)
    original = source['local_path']
    start, end = source['selected_range_ms']
    clip = folder / 'selected.mp4'
    _run([ffmpeg, '-y', '-v', 'error', '-ss', start / 1000, '-i', original, '-t', (end - start) / 1000,
          '-map', '0:v:0', '-map', '0:a:0', '-c:v', 'libx264', '-preset', 'fast', '-c:a', 'aac', clip])
    clip_info = probe(clip)
    if not clip_info['has_audio'] or not clip_info['width'] or abs(clip_info['duration_seconds'] - (end - start) / 1000) > .5:
        raise MediaError('Selected clip streams or duration do not match the requested range')
    assets = []
    for index, speaker in enumerate(source['speakers']):
        portrait = folder / ('speaker_{}_portrait.png'.format(index))
        args = [ffmpeg, '-y', '-v', 'error', '-ss', speaker['portrait_timestamp_ms'] / 1000, '-i', original, '-frames:v', '1']
        if speaker.get('portrait_crop'):
            x, y, w, h = speaker['portrait_crop']
            args += ['-vf', 'crop={}:{}:{}:{}:exact=1'.format(w, h, x, y)]
        _run(args + [str(portrait)])
        audio = folder / ('speaker_{}_reference.wav'.format(index))
        ranges = speaker['enrollment_ranges_ms']
        audio_origin = min(a for a, b in ranges)
        audio_end = max(b for a, b in ranges)
        chains = ['[0:a:0]atrim=start={}:end={},asetpts=PTS-STARTPTS[a{}]'.format((a - audio_origin) / 1000, (b - audio_origin) / 1000, i) for i, (a, b) in enumerate(ranges)]
        chains.append(''.join('[a{}]'.format(i) for i in range(len(ranges))) + 'concat=n={}:v=0:a=1[out]'.format(len(ranges)))
        _run([ffmpeg, '-y', '-v', 'error', '-ss', audio_origin / 1000, '-t', (audio_end - audio_origin) / 1000, '-i', original, '-filter_complex', ';'.join(chains), '-map', '[out]', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', audio])
        if audio.stat().st_size > 20 * 1024 * 1024:
            raise MediaError('Extracted reference exceeds 20 MiB')
        assets.append(dict(speaker, image_ref=str(portrait), image_hash=_hash(portrait), reference_audio_ref=str(audio),
                           reference_audio_hash=_hash(audio), reference_duration_seconds=probe(audio)['duration_seconds']))
    return {'selected_clip_path': str(clip), 'selected_clip_hash': _hash(clip), 'speakers': assets}


def ingest_sources(config, base_dir, run_dir):
    """Validate and extract independent sources, preserving blocked records in ingest.json."""
    base_dir, run_dir = Path(base_dir).resolve(), Path(run_dir).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    result = {'schema_version': 1, 'created_at': datetime.now(timezone.utc).isoformat(), 'sources': [], 'issues': []}
    sources = config.get('sources', [])
    if not isinstance(sources, list):
        sources = []
        result['issues'].append(_issue('invalid_sources', 'sources must be a list'))
    seen = set()
    for raw in sources:
        source = dict(raw) if isinstance(raw, dict) else {}
        if config.get('synthetic_fixture') is True:
            source['synthetic_fixture'] = True
        metadata = None
        try:
            if isinstance(source.get('local_path'), str) and source['local_path']:
                source['local_path'] = str(_path(source['local_path'], base_dir))
                if Path(source['local_path']).is_file():
                    source['file_hash'] = _hash(source['local_path'])
                metadata = probe(source['local_path'])
        except (MediaError, OSError, ValueError, subprocess.SubprocessError):
            pass  # Validator persists a concrete issue below.
        issues = _validate(source, base_dir, metadata)
        sid = source.get('source_id')
        if isinstance(sid, str) and sid in seen:
            issues.append(_issue('duplicate_source_id', 'source_id must be unique within the run'))
        if isinstance(sid, str):
            seen.add(sid)
        record = dict(source, issues=issues, status='blocked', media_info=metadata)
        if metadata:
            record['context_range_ms'] = midpoint_window(metadata['duration_seconds'])
        if not any(i['severity'] == 'error' for i in issues):
            try:
                record.update(_extract(source, metadata, run_dir))
                record['status'] = 'ready'
            except (MediaError, OSError, ValueError, subprocess.SubprocessError) as exc:
                issues.append(_issue('extraction_failed', str(exc)))
        result['sources'].append(record)
        result['issues'].extend(dict(i, source_id=sid) for i in issues)
    result['status'] = 'ready' if sources and not any(i['severity'] == 'error' for i in result['issues']) else 'blocked'
    if not sources:
        result['issues'].append(_issue('missing_source', 'No local sources configured'))
    result['content_hash'] = hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()
    output = run_dir / 'ingest.json'
    temporary = run_dir / 'ingest.json.tmp'
    temporary.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temporary.replace(output)
    return result
