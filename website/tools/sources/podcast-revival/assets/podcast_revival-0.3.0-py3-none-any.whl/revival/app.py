"""Local project service. No paid operation is dispatched by a page load."""
import copy
import os
import subprocess
from urllib.parse import urlsplit,urlunsplit
from pathlib import Path
from .util import read_json,write_json,resolve_path,now
from .ledger import Ledger

KEY_NAMES=('FAL_KEY','FAL_BILLING_KEY','OPENAI_API_KEY','ELEVENLABS_API_KEY')

def load_credentials():
    for name in KEY_NAMES:
        if not os.environ.get(name) and Path('/usr/bin/security').exists():
            result=subprocess.run(['/usr/bin/security','find-generic-password','-a','revival','-s','podcast-revival/'+name,'-w'],capture_output=True,text=True)
            if result.returncode==0 and result.stdout.strip():os.environ[name]=result.stdout.strip()

def save_credential(name,value):
    if name not in KEY_NAMES or not value or len(value)>2000:raise ValueError('Invalid credential')
    if not Path('/usr/bin/security').exists():raise ValueError('Set credentials in the process environment on this platform')
    result=subprocess.run(['/usr/bin/security','add-generic-password','-U','-a','revival','-s','podcast-revival/'+name,'-w',value],capture_output=True,text=True)
    if result.returncode:raise ValueError('macOS Keychain did not accept the credential')
    os.environ[name]=value

def sanitize(value):
    """Portable/UI views exclude credentials and temporary provider URLs."""
    if isinstance(value,dict):
        return {k:sanitize(v) for k,v in value.items() if isinstance(v,bool) or not any(word in k.lower() for word in ('token','authorization','custom_voice_id','api_key','secret'))}
    if isinstance(value,list):return [sanitize(x) for x in value]
    if isinstance(value,str):
        for key in KEY_NAMES:
            secret=os.environ.get(key)
            if secret:value=value.replace(secret,'[credential omitted]')
    if isinstance(value,str) and value.startswith(('http://','https://')):
        u=urlsplit(value)
        if u.query or u.username or u.password:return '[private provider URL omitted]'
    return value

def selected_config(config):
    current=copy.deepcopy(config)
    current['sources']=[s for s in current.get('sources',[]) if s.get('selected',True)]
    return current

class Project:
    def __init__(self,path):
        self.path=Path(path).resolve();self.base=self.path.parent
        self.reload()
    def reload(self):
        self.config=read_json(self.path);self.run=resolve_path(self.base,self.config.get('run_dir','run'));self.run.mkdir(parents=True,exist_ok=True)
        self.ledger=Ledger(self.run/'ledger.sqlite',self.config.get('budget',{}).get('limit_usd',100))
    def plan(self):
        c=selected_config(self.config);out=c.get('outputs',{});p=c.get('pricing',{})
        count=sum(len(s.get('speakers',[])) for s in c.get('sources',[]))
        lower=count if count else 4;upper=count if count else 8
        seconds=2*(out.get('update_seconds_per_language',180)+out.get('calibration_seconds_per_language',30))
        video=round(seconds*p.get('video_per_second_usd',.115),2)
        remainder=30 # TTS2 + research/ASR8 + repairs15 + taxes5
        totals=self.ledger.totals()
        return {'mode':'estimate_only','video_seconds':seconds,'video_usd':video,'clone_count_range':[lower,upper] if not count else [count,count],
          'clone_usd_range':[lower*p.get('clone_usd',1.5),upper*p.get('clone_usd',1.5)],'other_allowances_usd':remainder,
          'total_range_usd':[round(video+lower*p.get('clone_usd',1.5)+remainder,2),round(video+upper*p.get('clone_usd',1.5)+remainder,2)],
          'price_basis':p.get('basis'),'account_price_verified':p.get('account_verified',False),'ledger':totals,'estimated_not_actual':True}
    def preflight(self):
        from .ingest import validate_source,_binary
        c=selected_config(self.config);issues=[]
        for lang in ('zh','en'):
            if sum(s.get('language')==lang for s in c.get('sources',[]))!=1:issues.append({'code':'language_count','message':'Select one '+lang+' source','severity':'error'})
        for source in c.get('sources',[]):
            for issue in validate_source(source,self.base):issues.append(dict(issue,source_id=source.get('source_id')))
        keys={name:bool(os.environ.get(name)) for name in KEY_NAMES}
        pricing_report=None
        if keys['FAL_KEY']:
            from .pricing import verify_pricing
            pricing_report=verify_pricing(c,self.run)
            self.config.setdefault('pricing',{}).update(pricing_report['pricing'])
            write_json(self.path,self.config)
            c['pricing']=self.config['pricing']
        if not keys['FAL_KEY']:issues.append({'code':'missing_credential','message':'Connect fal to enable voice and video generation','severity':'error'})
        if not c.get('pricing',{}).get('account_verified'):issues.append({'code':'account_price_unverified','message':'Account pricing has not been checked; public prices are estimates','severity':'error'})
        for s in c.get('sources',[]):
            if not s.get('script_paths'):issues.append({'code':'missing_scripts','message':'Calibration and update scripts are not ready','source_id':s['source_id'],'severity':'error'})
        report={'created_at':now(),'status':'ready' if not any(i['severity']=='error' for i in issues) else 'blocked','credentials':keys,'ffmpeg_available':bool(_binary('ffmpeg')),'issues':issues,'paid_calls':0,'plan':self.plan(),'pricing_check':pricing_report}
        write_json(self.run/'preflight.json',report);return report
    def action(self,name):
        c=selected_config(self.config)
        if name=='plan':return self.plan()
        if name=='preflight':return self.preflight()
        if name=='ingest':
            from .ingest import ingest_sources
            return ingest_sources(c,self.base,self.run)
        if name in ('draft','prompts'):
            from .content import export_prompts
            return export_prompts(c,self.base,self.run)
        if name=='review':
            from .content import review_project
            return review_project(c,self.base,self.run)
        if name in ('render','resume'):
            if name=='render' and not self.config.get('pricing',{}).get('account_verified'):raise ValueError('Verify current account pricing before a paid submission')
            from .render import render_project
            return render_project(c,self.base,self.run,self.ledger,resume=name=='resume')
        if name=='reconcile':
            from .billing import reconcile_project
            return reconcile_project(self.ledger,run_dir=self.run)
        if name=='report':
            report=self.state();write_json(self.run/'report.json',report);return report
        raise ValueError('Unknown action')
    def update_selection(self,source_id,start_ms,end_ms):
        source=next((s for s in self.config['sources'] if s['source_id']==source_id),None)
        if not source:raise ValueError('Unknown source')
        a,b=source['context_range_ms']
        if not isinstance(start_ms,(int,float)) or not isinstance(end_ms,(int,float)) or not a<=start_ms<end_ms<=b:raise ValueError('Selection must stay inside the inspected context')
        if self.ledger.jobs():raise ValueError('Create a new revision after paid work has been reserved')
        for s in self.config['sources']:
            if s['language']==source['language']:s['selected']=s['source_id']==source_id
        source['selected_range_ms']=[round(start_ms),round(end_ms)]
        write_json(self.path,self.config);self.reload()
    def state(self):
        self.reload()
        reports={}
        for name in ('preflight','ingest','review','media'):
            path=self.run/(name+'.json')
            if path.exists():reports[name]=read_json(path)
        for d in reports.get('media',{}).get('deliverables',[]):
            for kind in ('video','audio'):
                if d.get(kind):d[kind]['playback_url']='/artifact/'+d['deliverable_id']+'/'+kind
        sources=copy.deepcopy(self.config.get('sources',[]))
        for s in sources:
            # Never return proof credentials or raw signed provider URLs.
            for sp in s.get('speakers',[]):sp.pop('custom_voice_id',None)
            s['thumbnail_url']='/media/thumbnail/'+s['source_id']
            s['video_url']='/media/source/'+s['source_id']
            s['audio_url']='/media/context/'+s['source_id']
            tp=s.get('transcript_path')
            if tp and resolve_path(self.base,tp).is_file():
                transcript=read_json(resolve_path(self.base,tp))
                s['transcript']=transcript
            for field,key in [('draft_path','draft'),('evidence_path','evidence')]:
                ref=s.get(field)
                if ref and resolve_path(self.base,ref).is_file():s[key]=read_json(resolve_path(self.base,ref))
        return sanitize({'name':'Revival','run_id':self.config.get('run_id'),'title':self.config.get('title'),'as_of':self.config.get('as_of'),'scope':self.config.get('scope'),
          'sources':sources,'plan':self.plan(),'reports':reports,'jobs':[{k:j[k] for k in ['job_id','operation','state','upper_bound','actual_cost','reserved_amount']} for j in self.ledger.jobs()],
          'credentials':{k:bool(os.environ.get(k)) for k in KEY_NAMES},'human_evaluation':None,'actual_media_cost_usd':self.ledger.totals()['actual_cost_usd'],
          'paid_media_calls':None if any(j['state']=='unknown' and not j['request_id'] for j in self.ledger.jobs()) else sum(bool(j['request_id']) for j in self.ledger.jobs()),
          'paid_request_attempts':sum(j['state'] in ('submitting','unknown','queued','completed','rejected') for j in self.ledger.jobs()),
          'known_provider_requests':sum(bool(j['request_id']) for j in self.ledger.jobs()),
          'unconfirmed_submissions':sum(j['state']=='unknown' and not j['request_id'] for j in self.ledger.jobs()),'export_note':'Local prototype. Generated voice/video and human evaluation are pending.'})
