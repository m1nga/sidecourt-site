---
name: mixtape-preview
description: Make a shareable browser preview when someone has chosen YouTube recordings and wants to keep them in a particular order.
---

If the user supplies a list of YouTube watch links or video IDs, extract each 11-character video ID. Preserve the order and any intentional repeats. Carry over the requested title, or use a short title based on the user's description.

If the request names songs without identifying recordings, ask for the intended links or use an available search tool to identify the specific versions first. Never guess a video ID. Confirm which recordings to include if there are more than 30.

Call create_playlist_preview with the title and one to 30 ordered video_ids. Return its preview_url as a clickable link and its track_count. Anyone receiving the link can see the title and selections. Playback availability depends on YouTube. A preview does not confirm a save to a music account.
